package me.loyalproboyy.spawn;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.UUID;

public class Spawn extends JavaPlugin {

    private final HashMap<UUID, Long> cooldown = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getLogger().info("Spawn Plugin Enabled!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (command.getName().equalsIgnoreCase("spawn")) {

            if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {

                if (!player.hasPermission("spawn.reload")) {
                    player.sendMessage("§cNo permission!");
                    return true;
                }

                reloadConfig();
                player.sendMessage("§aSpawn config reloaded!");
                return true;
            }

            int cooldownTime = getConfig().getInt("cooldown");

            if (cooldown.containsKey(player.getUniqueId())) {

                long secondsLeft = ((cooldown.get(player.getUniqueId()) / 1000) + cooldownTime)
                        - (System.currentTimeMillis() / 1000);

                if (secondsLeft > 0) {
                    player.sendMessage("§cYou must wait " + secondsLeft + " seconds before using spawn again.");
                    return true;
                }
            }

            cooldown.put(player.getUniqueId(), System.currentTimeMillis());

            int delay = getConfig().getInt("teleport-delay");

            player.sendMessage("§eTeleporting to spawn in " + delay + " seconds. Don't move!");

            Location start = player.getLocation();

            Bukkit.getScheduler().runTaskLater(this, () -> {

                if (!player.getLocation().getBlock().equals(start.getBlock())) {
                    player.sendMessage("§cTeleport cancelled because you moved!");
                    return;
                }

                String world = getConfig().getString("spawn.world");

                double x = getConfig().getDouble("spawn.x");
                double y = getConfig().getDouble("spawn.y");
                double z = getConfig().getDouble("spawn.z");

                Location spawn = new Location(Bukkit.getWorld(world), x, y, z);

                player.teleport(spawn);

                player.sendTitle("§aSpawn", "§7Teleported successfully", 10, 40, 10);

                player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1, 1);

                String cmd = getConfig().getString("console-command");
                cmd = cmd.replace("%player%", player.getName());

                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);

            }, delay * 20L);

            return true;
        }

        if (command.getName().equalsIgnoreCase("setspawn")) {

            if (!player.hasPermission("spawn.set")) {
                player.sendMessage("§cNo permission!");
                return true;
            }

            Location loc = player.getLocation();

            getConfig().set("spawn.world", loc.getWorld().getName());
            getConfig().set("spawn.x", loc.getX());
            getConfig().set("spawn.y", loc.getY());
            getConfig().set("spawn.z", loc.getZ());

            saveConfig();

            player.sendMessage("§aSpawn location set!");

            return true;
        }

        return false;
    }
}